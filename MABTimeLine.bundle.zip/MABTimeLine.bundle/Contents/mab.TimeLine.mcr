macroScript TimeLine category:"MYARTSBOX" tooltip:"Time Line"
(
    filein "mab.TimeLine.ms" 
)